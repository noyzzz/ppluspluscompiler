package IR;

import symboltable.SymbolTableVariable;
// result is a always a user defined variable
public class VariableAssignIR implements Quadruple {
    public SymbolTableVariable result;
    public SymbolTableVariable exprSymbol;
    public VariableAssignIR(SymbolTableVariable exprSymbol, SymbolTableVariable result) {
        this.result = result;
        this.exprSymbol = exprSymbol;
    }
}
