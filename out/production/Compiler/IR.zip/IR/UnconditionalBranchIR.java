package IR;

public class UnconditionalBranchIR implements Quadruple {
    public String label;
    public UnconditionalBranchIR(String label){
        this.label = label;
    }
}
