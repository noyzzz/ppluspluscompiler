package IR;

import symboltable.SymbolTable;
import symboltable.SymbolTableVariable;

/**
 * Created by Arash on 18/06/28.
 */
public interface  Quadruple {
/*    public Object operator;
    public Object argument1;
    public Object argument2;
    public Object result;*/

}

