package IR;

import java.util.HashMap;

public class SwitchIR  implements Quadruple{
    public Integer switch_id;
    public String defaultLabel;
    public HashMap<Integer,String> labels;
    public SwitchIR(Integer switch_id, String defaultLabel, HashMap<Integer,String> labels){
        this.switch_id = switch_id;
        this.labels = labels;
        this.defaultLabel = defaultLabel;
    }
}
