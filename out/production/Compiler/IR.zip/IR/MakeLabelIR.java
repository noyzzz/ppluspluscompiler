package IR;

public class MakeLabelIR implements Quadruple {
    public String labelName;
    public MakeLabelIR(String labelName){
        this.labelName = labelName;
    }
}
