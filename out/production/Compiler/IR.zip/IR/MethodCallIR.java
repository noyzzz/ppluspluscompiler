package IR;

import syntaxtree.Expr;

import java.util.Stack;

public class MethodCallIR implements Quadruple { // calling method
    public String name;
    public Stack<Expr> parameterStack;
    public MethodCallIR(String hash, Stack<Expr> parameterStack) {
        name = hash;
        this.parameterStack = parameterStack;
    }
}
